// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,frontLeftAsDcMotor,frontRightAsDcMotor,gamepad1,servo0AsServo

var rxSpd, spdMult, servoPos, elapsedTimeSpdControl, elapsedTimeServo0, y, x, rx, denominator;

/**
 * Describe this function...
 */
function rxSpeed() {
  if (gamepad1.getA() && elapsedTimeAccess.getMilliseconds(elapsedTimeSpdControl) >= 250) {
    spdMult = (typeof spdMult == 'number' ? spdMult : 0) + 0.1;
    rxSpd = (typeof rxSpd == 'number' ? rxSpd : 0) + 0.1;
    elapsedTimeAccess.reset(elapsedTimeSpdControl);
  } else if (gamepad1.getB() && elapsedTimeAccess.getMilliseconds(elapsedTimeSpdControl) >= 250) {
    spdMult = (typeof spdMult == 'number' ? spdMult : 0) + -0.1;
    rxSpd = (typeof rxSpd == 'number' ? rxSpd : 0) + -0.1;
    elapsedTimeAccess.reset(elapsedTimeSpdControl);
  }
  if (spdMult <= 0) {
    spdMult = 0.1;
  } else if (spdMult >= 1) {
    spdMult = 1;
  }
  if (rxSpd <= 0) {
    rxSpd = 0.1;
  } else if (rxSpd >= 1) {
    rxSpd = 1;
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rxSpd = 1;
  spdMult = 1;
  servoPos = 1;
  elapsedTimeSpdControl = elapsedTimeAccess.create();
  elapsedTimeServo0 = elapsedTimeAccess.create();
  backLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    rxSpeed();
    driftButton();
    servo0();
    y = -gamepad1.getLeftStickY();
    x = gamepad1.getLeftStickX() * 1.1;
    rx = gamepad1.getRightStickX();
    denominator = Math.max.apply(null, [[Math.abs(y), Math.abs(x), Math.abs(rx)].reduce(function(x, y) {return x + y;}), 1]);
    frontLeftAsDcMotor.setPower((y * spdMult + x * spdMult + rx * rxSpd) / denominator);
    backLeftAsDcMotor.setPower(((y * spdMult - x * spdMult) + rx * rxSpd) / denominator);
    frontRightAsDcMotor.setPower(((y * spdMult - x * spdMult) - rx * rxSpd) / denominator);
    backRightAsDcMotor.setPower(((y * spdMult + x * spdMult) - rx * rxSpd) / denominator);
    telemetry.addTextData('spdMult', String(spdMult));
    telemetry.addTextData('rxSpd', String(rxSpd));
    telemetryAddTextData('servoPos', servoPos);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function driftButton() {
  if (gamepad1.getRightTrigger() >= 0.25) {
    backLeftAsDcMotor.setZeroPowerBehavior("FLOAT");
    backRightAsDcMotor.setZeroPowerBehavior("FLOAT");
    frontLeftAsDcMotor.setZeroPowerBehavior("FLOAT");
    frontRightAsDcMotor.setZeroPowerBehavior("FLOAT");
  } else {
    backLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
    backRightAsDcMotor.setZeroPowerBehavior("BRAKE");
    frontLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
    frontRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  }
}

/**
 * Describe this function...
 */
function servo0() {
  if (gamepad1.getDpadLeft() && elapsedTimeAccess.getMilliseconds(elapsedTimeServo0) >= 50) {
    servoPos = (typeof servoPos == 'number' ? servoPos : 0) + -0.01;
    elapsedTimeAccess.reset(elapsedTimeServo0);
  } else if (gamepad1.getDpadRight() && elapsedTimeAccess.getMilliseconds(elapsedTimeServo0) >= 50) {
    servoPos = (typeof servoPos == 'number' ? servoPos : 0) + 0.01;
    elapsedTimeAccess.reset(elapsedTimeServo0);
  }
  if (servoPos <= 0) {
    servoPos = 0;
  } else if (servoPos >= 1) {
    servoPos = 1;
  }
  servo0AsServo.setPosition(servoPos);
}
