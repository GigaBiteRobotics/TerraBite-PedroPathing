// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,frontLeftAsDcMotor,frontRightAsDcMotor,gamepad1

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  backLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getA()) {
        backLeftAsDcMotor.setPower(0.1);
        backRightAsDcMotor.setPower(-0.1);
        frontLeftAsDcMotor.setPower(-0.1);
        frontRightAsDcMotor.setPower(0.1);
      }
      if (gamepad1.getB()) {
        backLeftAsDcMotor.setPower(-0.1);
        backRightAsDcMotor.setPower(0.1);
        frontLeftAsDcMotor.setPower(0.1);
        frontRightAsDcMotor.setPower(-0.1);
      }
    }
  }
}
