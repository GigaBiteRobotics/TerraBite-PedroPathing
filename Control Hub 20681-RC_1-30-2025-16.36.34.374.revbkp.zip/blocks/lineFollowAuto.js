// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,colorSensor1AsColorSensor,colorSensor2AsColorSensor,frontLeftAsDcMotor,frontRightAsDcMotor

var motorSpeed;

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  backLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  motorSpeed = 0.15;
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      telemetry.addLine('Sensor 1');
      telemetry.addTextData('blue val', String(colorSensor1AsColorSensor.getBlue()));
      telemetry.addTextData('red val', String(colorSensor1AsColorSensor.getRed()));
      telemetry.addTextData('green val', String(colorSensor1AsColorSensor.getGreen()));
      telemetry.addTextData('blue val', String(colorSensor2AsColorSensor.getBlue()));
      telemetry.addLine('Sensor 2');
      telemetry.addTextData('blue val', String(colorSensor2AsColorSensor.getBlue()));
      telemetry.addTextData('red val', String(colorSensor2AsColorSensor.getRed()));
      telemetry.addTextData('green val', String(colorSensor2AsColorSensor.getGreen()));
      telemetry.update();
      if (colorSensor2AsColorSensor.getRed() < 130) {
        backLeftAsDcMotor.setPower(-motorSpeed * 2);
        backRightAsDcMotor.setPower(motorSpeed * 2);
        frontLeftAsDcMotor.setPower(-motorSpeed * 2);
        frontRightAsDcMotor.setPower(motorSpeed * 2);
      }
      if (colorSensor1AsColorSensor.getRed() < 190) {
        backLeftAsDcMotor.setPower(motorSpeed * 2);
        backRightAsDcMotor.setPower(-motorSpeed * 2);
        frontLeftAsDcMotor.setPower(motorSpeed * 2);
        frontRightAsDcMotor.setPower(-motorSpeed * 2);
      }
      if (colorSensor1AsColorSensor.getRed() > 190 && colorSensor2AsColorSensor.getRed() > 130) {
        backLeftAsDcMotor.setPower(motorSpeed);
        backRightAsDcMotor.setPower(motorSpeed);
        frontLeftAsDcMotor.setPower(motorSpeed);
        frontRightAsDcMotor.setPower(motorSpeed);
      }
    }
  }
}
