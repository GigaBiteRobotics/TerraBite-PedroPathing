// IDENTIFIERS_USED=backLeftAsDcMotor,frontRightAsDcMotor

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  backLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    for (var count = 0; count < 1; count++) {
      backLeftAsDcMotor.setPower(0.5);
      frontRightAsDcMotor.setPower(0.5);
      linearOpMode.sleep(1000);
      backLeftAsDcMotor.setPower(0);
      frontRightAsDcMotor.setPower(0);
      linearOpMode.sleep(1000);
      backLeftAsDcMotor.setPower(-0.5);
      frontRightAsDcMotor.setPower(-0.5);
      linearOpMode.sleep(1000);
      backLeftAsDcMotor.setPower(0);
      frontRightAsDcMotor.setPower(0);
    }
  }
}
