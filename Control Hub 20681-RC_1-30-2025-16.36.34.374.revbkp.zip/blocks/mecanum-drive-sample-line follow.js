// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,colorSensor1AsColorSensor,colorSensor2AsColorSensor,frontLeftAsDcMotor,frontRightAsDcMotor,gamepad1,gamepad2

var rxSpd, spdMult, myElapsedTime, y, x, rx, denominator;

/**
 * Describe this function...
 */
function checkLOL() {
  if (gamepad2.getLeftStickButton() && gamepad2.getRightBumper()) {
    backLeftAsDcMotor.setDirection("FORWARD");
    backRightAsDcMotor.setDirection("REVERSE");
    frontLeftAsDcMotor.setDirection("FORWARD");
    frontRightAsDcMotor.setDirection("REVERSE");
  } else if (gamepad2.getLeftStickButton() && gamepad2.getLeftBumper()) {
    backLeftAsDcMotor.setDirection("REVERSE");
    backRightAsDcMotor.setDirection("FORWARD");
    frontLeftAsDcMotor.setDirection("REVERSE");
    frontRightAsDcMotor.setDirection("FORWARD");
  }
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  rxSpd = 1;
  spdMult = 1;
  myElapsedTime = elapsedTimeAccess.create();
  backLeftAsDcMotor.setDirection("REVERSE");
  frontLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  while (linearOpMode.opModeIsActive()) {
    if (gamepad2.getDpadDown()) {
      break;
    }
    if (colorSensor2AsColorSensor.getRed() < 140 || colorSensor1AsColorSensor.getRed() < 190) {
      backLeftAsDcMotor.setPower(0);
      backRightAsDcMotor.setPower(0);
      frontLeftAsDcMotor.setPower(0);
      frontRightAsDcMotor.setPower(0);
    }
    rxSpeed();
    checkLOL();
    driftButton();
    y = -gamepad1.getLeftStickY();
    x = gamepad1.getLeftStickX() * 1.1;
    rx = gamepad1.getRightStickX();
    denominator = Math.max.apply(null, [[Math.abs(y), Math.abs(x), Math.abs(rx)].reduce(function(x, y) {return x + y;}), 1]);
    frontLeftAsDcMotor.setPower((y * spdMult + x * spdMult + rx * rxSpd) / denominator);
    backLeftAsDcMotor.setPower(((y * spdMult - x * spdMult) + rx * rxSpd) / denominator);
    frontRightAsDcMotor.setPower(((y * spdMult - x * spdMult) - rx * rxSpd) / denominator);
    backRightAsDcMotor.setPower(((y * spdMult + x * spdMult) - rx * rxSpd) / denominator);
    telemetry.addTextData('spdMult', String(spdMult));
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function driftButton() {
  if (gamepad2.getRightTrigger() >= 0.25) {
    backLeftAsDcMotor.setZeroPowerBehavior("FLOAT");
    backRightAsDcMotor.setZeroPowerBehavior("FLOAT");
    frontLeftAsDcMotor.setZeroPowerBehavior("FLOAT");
    frontRightAsDcMotor.setZeroPowerBehavior("FLOAT");
  } else {
    backLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
    backRightAsDcMotor.setZeroPowerBehavior("BRAKE");
    frontLeftAsDcMotor.setZeroPowerBehavior("BRAKE");
    frontRightAsDcMotor.setZeroPowerBehavior("BRAKE");
  }
}

/**
 * Describe this function...
 */
function rxSpeed() {
  if (gamepad2.getA() && elapsedTimeAccess.getMilliseconds(myElapsedTime) >= 250) {
    spdMult = (typeof spdMult == 'number' ? spdMult : 0) + 0.1;
    rxSpd = (typeof rxSpd == 'number' ? rxSpd : 0) + 0.1;
    elapsedTimeAccess.reset(myElapsedTime);
  } else if (gamepad2.getB() && elapsedTimeAccess.getMilliseconds(myElapsedTime) >= 250) {
    spdMult = (typeof spdMult == 'number' ? spdMult : 0) + -0.1;
    rxSpd = (typeof rxSpd == 'number' ? rxSpd : 0) + -0.1;
    elapsedTimeAccess.reset(myElapsedTime);
  }
  if (spdMult <= 0) {
    spdMult = 0.1;
    rxSpd = 0.1;
  } else if (spdMult >= 1) {
    spdMult = 1;
    rxSpd = 1;
  }
}
