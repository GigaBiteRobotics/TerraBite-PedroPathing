// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,frontLeftAsDcMotor,frontRightAsDcMotor,gamepad1

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  backRightAsDcMotor.setDirection("REVERSE");
  frontRightAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      move();
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function move() {
  if (gamepad1.getDpadRight()) {
    backLeftAsDcMotor.setPower(0.4);
    backRightAsDcMotor.setPower(-0.4);
    frontLeftAsDcMotor.setPower(-0.4);
    frontRightAsDcMotor.setPower(0.4);
  } else if (gamepad1.getDpadLeft()) {
    backLeftAsDcMotor.setPower(-0.4);
    backRightAsDcMotor.setPower(0.4);
    frontLeftAsDcMotor.setPower(0.4);
    frontRightAsDcMotor.setPower(-0.4);
  }
  backLeftAsDcMotor.setPower(gamepad1.getLeftStickY());
  backRightAsDcMotor.setPower(gamepad1.getLeftStickY());
  frontLeftAsDcMotor.setPower(gamepad1.getLeftStickY());
  frontRightAsDcMotor.setPower(gamepad1.getLeftStickY());
  backLeftAsDcMotor.setPower(-gamepad1.getRightStickX());
  backRightAsDcMotor.setPower(gamepad1.getRightStickX());
  frontLeftAsDcMotor.setPower(-gamepad1.getRightStickX());
  frontRightAsDcMotor.setPower(gamepad1.getRightStickX());
  while (gamepad1.getA()) {
    backRightAsDcMotor.setPower(0.5);
    frontLeftAsDcMotor.setPower(0.5);
  }
  while (gamepad1.getY()) {
    backRightAsDcMotor.setPower(-0.5);
    frontLeftAsDcMotor.setPower(-0.5);
  }
  while (gamepad1.getB()) {
    backLeftAsDcMotor.setPower(0.5);
    frontRightAsDcMotor.setPower(0.5);
  }
  while (gamepad1.getX()) {
    backLeftAsDcMotor.setPower(-0.5);
    frontRightAsDcMotor.setPower(-0.5);
  }
  backRightAsDcMotor.setPower(0);
  frontLeftAsDcMotor.setPower(0);
  frontRightAsDcMotor.setPower(0);
  backLeftAsDcMotor.setPower(0);
}
