// IDENTIFIERS_USED=backLeftAsDcMotor,backRightAsDcMotor,frontLeftAsDcMotor,frontRightAsDcMotor

/**
 * This sample contains the bare minimum Blocks for any regular OpMode. The 3 blue
 * Comment Blocks show where to place Initialization code (runs once, after touching the
 * DS INIT button, and before touching the DS
 * Start arrow), Run code (runs once, after
 * touching Start), and Loop code (runs repeatedly
 * while the OpMode is active, namely not
 * Stopped).
 */
function runOpMode() {
  frontLeftAsDcMotor.setDirection("REVERSE");
  backLeftAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    backLeftAsDcMotor.setPower(-1);
    backRightAsDcMotor.setPower(1);
    frontRightAsDcMotor.setPower(1);
    frontLeftAsDcMotor.setPower(-1);
    linearOpMode.sleep(500);
  }
}
